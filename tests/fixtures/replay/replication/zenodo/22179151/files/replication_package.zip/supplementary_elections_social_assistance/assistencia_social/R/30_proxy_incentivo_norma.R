# 30_proxy_incentivo_norma.R ----------------------------------------------
# A PROXY DE INTENSIDADE DO INCENTIVO, CORRIGIDA PELA NORMA VIGENTE.
#
# MOTIVO. O 20_heterogeneidade_incentivo.R constroi os tercis de intensidade
# sobre FAMILIAS BENEFICIARIAS DO PBF per capita, com a justificativa de que
# "o repasse do IGD-M e proporcional ao numero de familias PBF do municipio".
# Essa regra vigorou ate 29/11/2011. A Portaria GM/MDS n. 319/2011 a
# substituiu ANTES da janela deste artigo comecar: desde dez/2011 o repasse e
#
#     IGD-M x R$ 3,25 x (cadastros validos ATUALIZADOS de familias com renda
#                        per capita ate 1/2 salario minimo)
#
# ou seja, a base fisica do pagamento e o numero de CADASTROS ATUALIZADOS do
# CadUnico, nao o numero de familias do PBF. (Portaria 754/2010 consolidada;
# Lei 12.058/2009, art. 6.)
#
# CUIDADO DE ENDOGENEIDADE. Usar a base REAL de pagamento como medida de
# intensidade seria endogeno: cadastros atualizados = TAC x estoque, e a TAC
# e o proprio desfecho. Por isso a intensidade tem de ser medida por uma
# proxy PRE-DETERMINADA do ESTOQUE de cadastros, nao do fluxo atualizado.
#
# O QUE ESTE SCRIPT FAZ. Reestima o gradiente de H2 com tres proxies e
# compara, em vez de apenas trocar uma pela outra:
#   (P1) familias PBF per capita, 2014      -- a atual, pela norma revogada
#   (P2) cadastros CadUnico per capita, 2014 -- estoque de cadastros,
#        pre-determinado, do BigQuery (familias_cadastradas_cu)
#   (P3) familias ate 1/2 SM per capita, 2015 -- o DENOMINADOR DA PROPRIA TAC,
#        que e a populacao exata da base de pagamento (familias_cu, VIS DATA).
#        So existe a partir de 2015, mas e pre-determinada em relacao as
#        coortes que identificam (2017-2018).
#
# Se o gradiente sobrevive nas tres, H2 e robusta a proxy e a correcao e de
# redacao. Se so sobrevive em P1, a contribuicao do artigo esta apoiada numa
# regra que nao vigorava.
#
# Saida: output/data/proxy_incentivo_norma.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))

painel <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
painel <- painel[ano <= 2019L]

## ---- as tres proxies, todas em tercis ----------------------------------
rotulos <- function(nm) c(paste0("1o tercil (incentivo fraco) -- ", nm),
                          paste0("2o tercil (medio) -- ", nm),
                          paste0("3o tercil (forte) -- ", nm))

fazer_tercil <- function(dt, var, ano_base, nome) {
  b <- dt[ano == ano_base, .(id = cod_ibge6, x = get(var) / populacao)]
  b <- b[is.finite(x)]
  b[, grupo := cut(x, quantile(x, c(0, 1/3, 2/3, 1), na.rm = TRUE),
                   labels = rotulos(nome), include.lowest = TRUE)]
  b[, .(id, grupo = as.character(grupo))]
}

P1 <- fazer_tercil(painel, "familias_beneficiarias_pbf", 2014L, "PBF pc 2014")
P2 <- fazer_tercil(painel, "familias_cadastradas_cu",    2014L, "cadastros CU pc 2014")
P3 <- fazer_tercil(painel, "familias_cu",                2015L, "familias <=1/2 SM pc 2015")

## ---- correlacao entre as proxies (a pergunta pratica: elas concordam?) --
cmp <- merge(merge(P1[, .(id, p1 = grupo)], P2[, .(id, p2 = grupo)], by = "id"),
             P3[, .(id, p3 = grupo)], by = "id")
conc <- function(a, b) mean(substr(cmp[[a]], 1, 2) == substr(cmp[[b]], 1, 2))
cat("\n==== CONCORDANCIA DE TERCIL ENTRE AS PROXIES ====\n")
cat(sprintf("P1 (PBF) x P2 (cadastros CU): %.1f%% dos municipios no mesmo tercil\n",
            100 * conc("p1", "p2")))
cat(sprintf("P1 (PBF) x P3 (<=1/2 SM):     %.1f%%\n", 100 * conc("p1", "p3")))
cat(sprintf("P2 x P3:                      %.1f%%\n", 100 * conc("p2", "p3")))

## ---- estimacao (mesma funcao do 20_, Sun-Abraham agregado) -------------
d0 <- painel[, .(id = cod_ibge6, ano, g, y = tx_atual_cad)][is.finite(y)]

att_sa <- function(df) {
  df <- copy(df); df[, g_sa := ifelse(g == 0, 10000L, g)]
  m <- tryCatch(feols(y ~ sunab(g_sa, ano) | id + ano, df, cluster = ~id),
                error = function(e) NULL)
  if (is.null(m)) return(data.table(att=NA_real_, ep=NA_real_, p=NA_real_, n_trat=NA_integer_))
  ct <- tryCatch(summary(m, agg = "att")$coeftable, error = function(e) NULL)
  if (is.null(ct)) return(data.table(att=NA_real_, ep=NA_real_, p=NA_real_, n_trat=NA_integer_))
  data.table(att = ct[1,1], ep = ct[1,2], p = ct[1,4], n_trat = uniqueN(df[g > 0]$id))
}

estimar <- function(proxy, etiqueta) {
  d <- merge(d0, proxy, by = "id")
  rbindlist(lapply(sort(unique(d$grupo)), function(gg)
    cbind(proxy = etiqueta, grupo = gg, att_sa(d[grupo == gg]))))
}

out <- rbindlist(list(
  estimar(P1, "P1 -- familias PBF pc 2014 (norma revogada)"),
  estimar(P2, "P2 -- cadastros CadUnico pc 2014"),
  estimar(P3, "P3 -- familias <=1/2 SM pc 2015 (base de pagamento)")))

## ---- o gradiente: fraco menos forte, em cada proxy ----------------------
grad <- out[, {
  fr <- att[grepl("^1o", grupo)]; ft <- att[grepl("^3o", grupo)]
  .(gradiente = fr - ft, att_fraco = fr, att_forte = ft)
}, by = proxy]

fwrite(out, file.path(DIR_OUT_DATA, "proxy_incentivo_norma.csv"))
fwrite(grad, file.path(DIR_OUT_DATA, "proxy_incentivo_norma_gradiente.csv"))

cat("\n==== ATT DA TAC POR TERCIL, TRES PROXIES (Sun-Abraham) ====\n")
print(out[, .(proxy, grupo, att = round(att, 4), ep = round(ep, 4),
              p = round(p, 3), n_trat)])
cat("\n==== O GRADIENTE (fraco - forte) EM CADA PROXY ====\n")
print(grad[, .(proxy, gradiente = round(gradiente, 4),
               att_fraco = round(att_fraco, 4), att_forte = round(att_forte, 4))])

# ========================================================================
# (b) RESIDUALIZACAO E PERMUTACAO REFEITAS SOBRE A PROXY CORRETA (P3).
#     O 20_ faz as duas sobre a P1 (norma revogada). Aqui elas sao refeitas
#     sobre familias <=1/2 SM per capita (2015), a populacao da base de
#     pagamento segundo a Portaria 319/2011.
# ------------------------------------------------------------------------

## Residualizacao: incentivo liquido de riqueza, porte e capacidade --------
base_res3 <- painel[ano == 2015, .(id = cod_ibge6, x = familias_cu / populacao)]
conf <- painel[ano == 2014, .(id = cod_ibge6, log_pib_pc, log_pop,
                              alfab = taxa_alfabetizacao)]
base_res3 <- merge(base_res3, conf, by = "id")
base_res3 <- base_res3[is.finite(x) & is.finite(log_pib_pc) &
                       is.finite(log_pop) & is.finite(alfab)]
fit3 <- lm(x ~ log_pib_pc + log_pop + alfab, data = base_res3)
base_res3[, x_resid := residuals(fit3)]
base_res3[, grupo := cut(x_resid, quantile(x_resid, c(0, 1/3, 2/3, 1), na.rm = TRUE),
  labels = rotulos("residual <=1/2 SM"), include.lowest = TRUE)]

d3 <- merge(d0, base_res3[, .(id, grupo = as.character(grupo))], by = "id")
res3 <- rbindlist(lapply(sort(unique(d3$grupo)), function(gg)
  cbind(grupo = gg, att_sa(d3[grupo == gg]))))
# O R2 do confundimento e um numero citado no corpo: persistir, nao so imprimir.
res3[, r2_confundimento := summary(fit3)$r.squared]
fwrite(res3, file.path(DIR_OUT_DATA, "proxy_incentivo_norma_residual.csv"))
cat("\n==== P3 RESIDUALIZADA (liquida de PIB pc, populacao, alfabetizacao) ====\n")
cat("R2 (familias <=1/2 SM pc ~ PIB pc + pop + alfab):",
    round(summary(fit3)$r.squared, 3), "\n")
print(res3[, .(grupo, att = round(att, 4), ep = round(ep, 4),
               p = round(p, 3), n_trat)])

## Permutacao do gradiente sob a P3 ---------------------------------------
setFixest_nthreads(1)
dP3 <- merge(d0, P3, by = "id")
lab_f <- grep("^1o", unique(dP3$grupo), value = TRUE)
lab_F <- grep("^3o", unique(dP3$grupo), value = TRUE)
g_obs <- out[proxy %like% "^P3" & grupo == lab_f, att] -
         out[proxy %like% "^P3" & grupo == lab_F, att]

mapa0 <- unique(dP3[, .(id, grupo)])
dbase <- dP3[, .(id, ano, g, y)]
estat <- function(mp) {
  df <- merge(dbase, mp, by = "id")
  att_sa(df[grupo == lab_f])$att - att_sa(df[grupo == lab_F])$att
}

B <- 1000L
set.seed(20250627)
perm <- numeric(B)
for (b in seq_len(B)) {
  mp <- copy(mapa0); mp[, grupo := sample(grupo)]
  perm[b] <- estat(mp[, .(id, grupo)])
}
perm <- perm[is.finite(perm)]
p_perm3 <- (1 + sum(perm <= g_obs)) / (1 + length(perm))
perm3 <- data.table(proxy = "P3 -- familias <=1/2 SM pc 2015",
  estatistica = "ATT(fraco) - ATT(forte)", gradiente_obs = g_obs,
  n_perm = length(perm), p_permutacao_unilateral = p_perm3,
  quantil_5pct = quantile(perm, 0.05, names = FALSE),
  quantil_95pct = quantile(perm, 0.95, names = FALSE))
fwrite(perm3, file.path(DIR_OUT_DATA, "proxy_incentivo_norma_permutacao.csv"))
cat("\n==== PERMUTACAO DO GRADIENTE SOB A P3 ====\n")
print(perm3)
