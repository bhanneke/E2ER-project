# 08_robustez.R ----------------------------------------------------------
# Robustez do braco de assistencia social:
#   (A) Teste de PRE-TENDENCIAS (leads conjuntamente nulos, Sun-Abraham).
#   (B) Janela ESTENDIDA 2012-2024 (Callaway-SantAnna sem controles; os
#       controles do pai so cobrem 2012-2019). Cautela: 2020-2024 carrega
#       pandemia + Auxilio Emergencial/Brasil/Novo BF -> ver README.
#   (C) Contraste-chave de MECANISMO: indicadores DISCRICIONARIOS de busca
#       ativa (TAC) caem, enquanto a transferencia FEDERAL/REGRADA (valor PBF)
#       nao -- espelha o contraste do braco de saude.
#
# Entrada: output/data/painel_assistencia_completo.csv
# Saidas : output/data/robustez_pretendencias.csv,
#          output/data/robustez_janela_2012_2024.csv,
#          output/data/contraste_discricionario_federal.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))
instalar_se_preciso(c("did"))

painel0 <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
painel0[, log_fam_cu    := log1p(familias_cadastradas_cu)]
painel0[, log_fam_pbf   := log1p(familias_beneficiarias_pbf)]
painel0[, log_valor_pbf := log1p(valor_pago_pbf_ano)]
painel0[, log_n_cras    := log1p(n_cras)]
painel0[, log_trab_cras := log1p(n_trab_cras)]

DESFECHOS <- c(
  "Atualizacao cadastral (TAC)"          = "tx_atual_cad",
  "CadUnico: familias cadastradas (log)" = "log_fam_cu",
  "PBF: familias beneficiarias (log)"    = "log_fam_pbf",
  "PBF: valor pago (log)"                = "log_valor_pbf",
  "CRAS: numero de unidades (log)"       = "log_n_cras",
  "CRAS: trabalhadores (log)"            = "log_trab_cras")

prep <- function(pn, ycol) {
  df <- pn[, .(id=cod_ibge6, ano, g, y=get(ycol))]
  comp <- df[, .(ok=all(!is.na(y))), by=id][ok==TRUE, id]
  df <- df[id %in% comp]
  df[, g_sa := ifelse(g==0, 10000L, g)]
  df[]
}
tem <- function(ycol) ycol %in% names(painel0) && !all(is.na(painel0[[ycol]]))

## (A) Pre-tendencias: Wald conjunto dos leads (rel < -1) ------------------
# Janela observada por desfecho (a TAC so existe 2015+; CRAS 2012+), SEMPRE
# limitada a JANELA PRIMARIA (<=2019): fora dela as coortes 2020+ estao
# codificadas g=0 e contaminariam o grupo de controle nos proprios pos-
# tratamentos (alem de pandemia/AE/AB). A janela estendida e o bloco (B),
# que recodifica g corretamente.
JAN_MAX <- 2019L
anos_obs <- function(yc) painel0[ano <= JAN_MAX,
  .(c=mean(!is.na(get(yc)))), by=ano][c>0.5, sort(ano)]
pre <- rbindlist(lapply(names(DESFECHOS), function(d) {
  yc <- DESFECHOS[[d]]; if (!tem(yc)) return(NULL)
  ao <- anos_obs(yc); df <- prep(painel0[ano %in% ao], yc)
  if (!uniqueN(df[g>0]$id)) return(NULL)
  m <- feols(y ~ sunab(g_sa, ano) | id + ano, data=df, cluster=~id)
  cf <- coef(m); leads <- grep("ano::-([2-9]|[0-9]{2})", names(cf), value=TRUE)
  wp <- tryCatch(wald(m, keep=leads)$p, error=function(e) NA_real_)
  data.table(desfecho=d, n_leads=length(leads), wald_p_pretend=round(wp,3))
}), fill=TRUE)
fwrite(pre, file.path(DIR_OUT_DATA, "robustez_pretendencias.csv"))

## (B) Janela estendida 2012-2024 (CS sem controles) ----------------------
ext <- rbindlist(lapply(names(DESFECHOS), function(d) {
  yc <- DESFECHOS[[d]]; if (!tem(yc)) return(NULL)
  pn <- copy(painel0)
  pn[, g := fifelse(g_cohort>=2012 & g_cohort<=2024, g_cohort, 0L)]  # janela ampla
  # Recorta aos anos com cobertura nacional do desfecho (evita derrubar todo
  # municipio na exigencia de painel balanceado quando a serie termina antes).
  anos_obs <- pn[, .(cob = mean(!is.na(get(yc)))), by=ano][cob>0.5, sort(ano)]
  pn <- pn[ano %in% anos_obs]
  df <- prep(pn, yc); if (!uniqueN(df[g>0]$id)) return(NULL)
  cs <- tryCatch(did::att_gt(yname="y", tname="ano", idname="id", gname="g",
          data=df, control_group="notyettreated", base_period="universal",
          bstrap=TRUE, cband=TRUE), error=function(e) NULL)
  if (is.null(cs)) return(NULL)
  s <- did::aggte(cs, type="simple", na.rm=TRUE)
  data.table(desfecho=d,
             janela=paste0(min(anos_obs), "-", max(anos_obs)),
             estimador="Callaway-SantAnna",
             att=round(s$overall.att,4), ep=round(s$overall.se,4),
             n_tratados=uniqueN(df[g>0]$id))
}), fill=TRUE)
fwrite(ext, file.path(DIR_OUT_DATA, "robustez_janela_2012_2024.csv"))

## (C) Contraste discricionario (TAC) x federal (valor PBF) ----------------
res_arq <- file.path(DIR_OUT_DATA, "resultados_did.csv")
if (file.exists(res_arq)) {
  r <- fread(res_arq)
  contraste <- r[estimador=="Callaway-SantAnna" & spec=="sem controles" &
                 desfecho %in% c("Atualizacao cadastral (TAC)",
                                 "PBF: valor pago (log)")]
  fwrite(contraste, file.path(DIR_OUT_DATA, "contraste_discricionario_federal.csv"))
} else contraste <- data.table()

cat("\n==== (A) PRE-TENDENCIAS (Wald p; >0,10 = ok) ====\n"); print(pre)
cat("\n==== (B) JANELA 2012-2024 (CS) ====\n"); print(ext)
cat("\n==== (C) CONTRASTE discricionario x federal ====\n")
if (nrow(contraste)) print(contraste[, .(desfecho, att, ep)]) else
  cat("(TAC ainda sem dados -- rode 03_igd_tac_mds.R e 07_did.R)\n")
