# 07_did.R ---------------------------------------------------------------
# DiD escalonado do efeito das eleicoes suplementares sobre a ASSISTENCIA
# SOCIAL. Porte direto da maquinaria de R/05_did.R do braco de saude:
# 4 estimadores (TWFE, Callaway-SantAnna, Borusyak, Wooldridge ETWFE) com e
# sem controles + estudo de evento (Sun-Abraham e CS dinamico).
#
# Janela primaria: 2012-2019 (espelha o braco de saude). Desfechos:
#   - tx_atual_cad ............ TAC, ANCORA H1 (busca ativa/visita domiciliar)
#   - log familias cadastradas CadUnico ... cobertura/estoque
#   - log familias beneficiarias PBF ...... beneficio (concessao/manutencao)
#   - log valor pago PBF .................. beneficio (contraste federal/regrado)
#   - log n_cras .......................... oferta de equipamento SUAS
# Desfechos sem dado (ex.: TAC/CRAS antes de obter os arquivos do MDS) sao
# pulados automaticamente.
#
# Entrada: output/data/painel_assistencia_completo.csv
# Saidas : output/figures/event_study_*.png ; output/data/resultados_did.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))
instalar_se_preciso(c("did"))
tem_didimp <- requireNamespace("didimputation", quietly = TRUE)
tem_etwfe  <- requireNamespace("etwfe", quietly = TRUE)

PERIODO <- c(2012L, 2019L)  # janela primaria de identificacao

painel <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
painel <- painel[ano >= PERIODO[1] & ano <= PERIODO[2]]

# Transformacoes log dos desfechos de contagem/valor (efeito em ~%) --------
painel[, log_fam_cu   := log1p(familias_cadastradas_cu)]
painel[, log_fam_pbf  := log1p(familias_beneficiarias_pbf)]
painel[, log_valor_pbf:= log1p(valor_pago_pbf_ano)]
painel[, log_n_cras   := log1p(n_cras)]
painel[, log_trab_cras:= log1p(n_trab_cras)]

DESFECHOS <- c(
  "Atualizacao cadastral (TAC)"          = "tx_atual_cad",
  "CadUnico: familias cadastradas (log)" = "log_fam_cu",
  "PBF: familias beneficiarias (log)"    = "log_fam_pbf",
  "PBF: valor pago (log)"                = "log_valor_pbf",
  "CRAS: numero de unidades (log)"       = "log_n_cras",
  "CRAS: trabalhadores (log)"            = "log_trab_cras")

# Controles X_it pre-determinados (cautela bad-control: nada de beneficio/CRAS)
CONTROLES <- c("log_pib_pc", "log_pop", "taxa_alfabetizacao")
XBASE     <- "taxa_alfabetizacao"

# ------------------------------------------------------------------------
roda_desfecho <- function(rotulo, ycol) {
  if (!ycol %in% names(painel) || all(is.na(painel[[ycol]]))) {
    message("PULANDO '", rotulo, "' (", ycol, " sem dados).")
    return(NULL)
  }
  message("\n############ ", rotulo, " ############")
  vars <- c("cod_ibge6", "ano", "g", ycol, CONTROLES)
  df <- painel[, ..vars]
  setnames(df, c("cod_ibge6", ycol), c("id", "y"))
  # Recorta aos anos com cobertura nacional do desfecho (a TAC so existe de
  # 2015+; o Censo SUAS de 2012+), para nao derrubar todos os municipios na
  # exigencia de painel balanceado quando a serie nao cobre toda a janela.
  anos_obs <- df[, .(cob = mean(!is.na(y))), by = ano][cob > 0.5, sort(ano)]
  if (length(anos_obs)) df <- df[ano %in% anos_obs]
  comp <- df[, .(ok = all(!is.na(y))), by = id][ok == TRUE, id]
  df <- df[id %in% comp]
  if (!uniqueN(df[g > 0]$id)) { message("Sem tratados com painel completo."); return(NULL) }
  df[, d_pos := as.integer(g > 0 & ano >= g)]
  df[, controles_ok := complete.cases(df[, ..CONTROLES])]
  message("Municipios: ", uniqueN(df$id),
          " | tratados: ", uniqueN(df[g > 0]$id),
          " | obs c/ controles: ", round(100*mean(df$controles_ok)), "%")

  fml_ctrl <- paste(CONTROLES, collapse = " + ")
  res <- list()

  ## (1) TWFE ---------------------------------------------------------------
  m1  <- feols(y ~ d_pos | id + ano, data = df, cluster = ~id)
  m1c <- feols(as.formula(paste0("y ~ d_pos + ", fml_ctrl, " | id + ano")),
               data = df[controles_ok == TRUE], cluster = ~id)
  res$twfe   <- data.table(estimador="TWFE", spec="sem controles",
                           att=coef(m1)["d_pos"], ep=se(m1)["d_pos"])
  res$twfe_c <- data.table(estimador="TWFE", spec="com controles",
                           att=coef(m1c)["d_pos"], ep=se(m1c)["d_pos"])

  ## (2) Callaway & Sant'Anna ----------------------------------------------
  cs <- tryCatch(did::att_gt(yname="y", tname="ano", idname="id", gname="g",
            data=df, control_group="notyettreated", base_period="universal",
            bstrap=TRUE, cband=TRUE), error=function(e){message("CS: ",e$message);NULL})
  cs_dyn <- NULL
  if (!is.null(cs)) {
    cs_s <- did::aggte(cs, type="simple", na.rm=TRUE)
    cs_dyn <- did::aggte(cs, type="dynamic", na.rm=TRUE)
    res$cs <- data.table(estimador="Callaway-SantAnna", spec="sem controles",
                         att=cs_s$overall.att, ep=cs_s$overall.se)
    csc <- tryCatch(did::att_gt(yname="y", tname="ano", idname="id", gname="g",
              data=df, control_group="notyettreated", base_period="universal",
              xformla=as.formula(paste("~", XBASE)), bstrap=TRUE, cband=TRUE),
              error=function(e) NULL)
    if (!is.null(csc)) { csc_s <- did::aggte(csc, type="simple", na.rm=TRUE)
      res$cs_c <- data.table(estimador="Callaway-SantAnna", spec="com controles",
                             att=csc_s$overall.att, ep=csc_s$overall.se) }
  }

  ## (3) Borusyak (imputacao) ----------------------------------------------
  if (tem_didimp) {
    bjs <- tryCatch(didimputation::did_imputation(data=df, yname="y", gname="g",
              tname="ano", idname="id"), error=function(e) NULL)
    if (!is.null(bjs)) res$bjs <- data.table(estimador="Borusyak (imputacao)",
        spec="sem controles", att=bjs$estimate[1], ep=bjs$std.error[1])
  }

  ## (4) Wooldridge ETWFE ---------------------------------------------------
  if (tem_etwfe) {
    w <- tryCatch(etwfe::etwfe(fml=y~1, tvar=ano, gvar=g,
            data=as.data.frame(df), vcov=~id), error=function(e) NULL)
    if (!is.null(w)) { e <- etwfe::emfx(w, type="simple")
      res$wool <- data.table(estimador="Wooldridge (ETWFE)", spec="sem controles",
                             att=e$estimate[1], ep=e$std.error[1]) }
  }

  ## Estudo de evento (Sun-Abraham + CS dinamico) --------------------------
  df[, g_sa := ifelse(g==0, 10000, g)]
  sa  <- feols(y ~ sunab(g_sa, ano) | id + ano, data=df, cluster=~id)
  pega_es <- function(m, lab){ a<-coef(m); s<-se(m)
    k<-grepl("year::|ano::", names(a)); rel<-as.integer(gsub(".*::(-?[0-9]+).*","\\1",names(a)[k]))
    data.table(rel=rel, att=as.numeric(a[k]), se=as.numeric(s[k]), fonte=lab) }
  es <- pega_es(sa, "Sun-Abraham")
  if (!is.null(cs_dyn)) es <- rbind(es,
    data.table(rel=cs_dyn$egt, att=cs_dyn$att.egt, se=cs_dyn$se.egt,
               fonte="Callaway-Sant'Anna"))
  es <- es[is.finite(rel) & rel>=-5 & rel<=5]

  p <- ggplot(es, aes(rel, att, color=fonte, fill=fonte)) +
    geom_hline(yintercept=0, linetype=2, color="grey40") +
    geom_vline(xintercept=-0.5, linetype=3, color="grey60") +
    geom_ribbon(aes(ymin=att-1.96*se, ymax=att+1.96*se), alpha=.12, color=NA) +
    geom_line() + geom_point(size=1.6) + scale_x_continuous(breaks=-5:5) +
    labs(title=paste0("Estudo de evento - ", rotulo),
         subtitle="Eleicoes suplementares (t = ano da eleicao)",
         x="Anos relativos a eleicao suplementar", y="Efeito estimado",
         color=NULL, fill=NULL) + theme(legend.position="bottom")
  slug <- gsub("[^a-z0-9]+","_", tolower(iconv(rotulo,"","ASCII//TRANSLIT")))
  ggsave(file.path(DIR_OUT_FIG, paste0("event_study_", slug, ".png")),
         p, width=8, height=5, dpi=150)

  tab <- rbindlist(res, fill=TRUE); tab[, desfecho:=rotulo]; tab[]
}

resultados <- rbindlist(lapply(names(DESFECHOS), function(d)
  roda_desfecho(d, DESFECHOS[[d]])), fill=TRUE)

if (nrow(resultados)) {
  setcolorder(resultados, c("desfecho","estimador","spec","att","ep"))
  fwrite(resultados, file.path(DIR_OUT_DATA, "resultados_did.csv"))
  cat("\n==== RESULTADOS DiD (ATT medio) ====\n")
  print(resultados[, .(desfecho, estimador, spec,
                       att=round(att,4), ep=round(ep,4))])
  cat("\nFiguras:", DIR_OUT_FIG, "\nTabela:",
      file.path(DIR_OUT_DATA,"resultados_did.csv"), "\n")
} else {
  cat("\nNenhum desfecho com dados suficientes ainda.\n")
}
