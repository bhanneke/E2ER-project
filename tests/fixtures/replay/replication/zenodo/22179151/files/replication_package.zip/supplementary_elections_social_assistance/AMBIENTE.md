# Ambiente de execução

Gerado em 2026-08-30 

```
R version 4.6.1 (2026-06-24)
Plataforma: x86_64-pc-linux-gnu
Sistema:    Ubuntu 26.04.1 LTS

Pacotes usados pelo pipeline:
  data.table   1.18.4
  fixest       0.14.2
  did          2.5.1
  ggplot2      4.0.3
  knitr        1.51
  HonestDiD    0.2.8
  MatchIt      4.7.2
  broom        1.0.13
  here         1.0.2
```
