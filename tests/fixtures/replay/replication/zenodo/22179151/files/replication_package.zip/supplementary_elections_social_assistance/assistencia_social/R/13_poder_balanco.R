# 13_poder_balanco.R -----------------------------------------------------
# (A) PODER / MDE (espelha R/32 do pai): efeito minimo detectavel a 80% de
#     poder, 5% bilateral (MDE = 2.80 * EP), por desfecho, sob Sun-Abraham e
#     Callaway-SantAnna. Critico para o desfecho-ancora: mostra que o NULO da
#     TAC e informativo (o desenho detectaria um efeito relevante).
# (B) BALANCO tratados (g>0) x nunca-tratados (g==0) na linha de base
#     (espelha R/33): diferencas padronizadas (SMD) de covariaveis pre-choque.
# Saidas: output/data/poder_mde.csv, balanco_tratado_naotratado.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))
instalar_se_preciso("did")
k <- qnorm(.975) + qnorm(.80)   # ~2.80

painel <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
# JANELA PRIMARIA (<=2019): o MDE deve medir o poder do DESENHO PRINCIPAL;
# alem de 2019 as coortes 2020+ estao codificadas g=0 (contaminacao).
painel <- painel[ano <= 2019L]
painel[, log_trab_cras := log1p(n_trab_cras)]
painel[, log_fam_cu    := log1p(familias_cadastradas_cu)]
painel[, log_n_cras    := log1p(n_cras)]
painel[, log_fam_pbf   := log1p(familias_beneficiarias_pbf)]
painel[, log_valor_pbf := log1p(valor_pago_pbf_ano)]

ALVO <- c("TAC (ancora)"                    = "tx_atual_cad",
          "CadUnico: familias (log)"        = "log_fam_cu",
          "CRAS: trabalhadores (log)"       = "log_trab_cras",
          "CRAS: unidades (log)"            = "log_n_cras",
          "PBF: familias (log)"             = "log_fam_pbf",
          "PBF: valor (log)"                = "log_valor_pbf")

att_sa <- function(yc){
  d <- painel[is.finite(get(yc)), .(id=cod_ibge6, ano, g, y=get(yc))]
  d[, g_sa := ifelse(g==0,10000L,g)]
  m <- feols(y ~ sunab(g_sa, ano) | id+ano, d, cluster=~id)
  ct <- summary(m, agg="att")$coeftable; data.table(att_sa=ct[1,1], ep_sa=ct[1,2])
}
att_cs <- function(yc){
  d <- painel[is.finite(get(yc)), .(id=cod_ibge6, ano, g, y=get(yc))]
  comp <- d[, .(ok=all(!is.na(y))), by=id][ok==TRUE, id]; d <- d[id %in% comp]
  cs <- tryCatch(did::att_gt(yname="y",tname="ano",idname="id",gname="g",data=d,
          control_group="notyettreated", base_period="universal",
          bstrap=TRUE,cband=TRUE), error=function(e) NULL)
  if (is.null(cs)) return(data.table(att_cs=NA_real_, ep_cs=NA_real_))
  a <- did::aggte(cs, type="simple", na.rm=TRUE)
  data.table(att_cs=a$overall.att, ep_cs=a$overall.se)
}
res <- rbindlist(lapply(names(ALVO), function(rot)
  cbind(desfecho=rot, att_sa(ALVO[[rot]]), att_cs(ALVO[[rot]]))), fill=TRUE)
res[, `:=`(mde80_sa=k*ep_sa, mde80_cs=k*ep_cs,
           detecta_cs = abs(att_cs) >= k*ep_cs)]
fwrite(res, file.path(DIR_OUT_DATA, "poder_mde.csv"))

## (B) Balanco tratados x nunca-tratados (linha de base) ------------------
# Para cada covariavel/desfecho-base, usa o 1o ano observado da serie.
painel[, grupo := fifelse(g>0, "treated", fifelse(tratado_alguma_vez==0, "never", "other"))]
base_ano <- function(col, ano0) painel[ano==ano0 & grupo %in% c("treated","never"),
                                       .(grupo, v=get(col))]
vars <- list(c("log_pib_pc","log PIB pc",2012L), c("log_pop","log Populacao",2012L),
             c("taxa_alfabetizacao","Alfabetizacao (%)",2012L),
             c("log_fam_cu","CadUnico familias (log)",2012L),
             c("tx_atual_cad","TAC (base 2015)",2015L),
             c("log_trab_cras","CRAS trabalhadores (log)",2012L))
smd <- function(col, ano0){
  b <- base_ano(col, ano0)
  t <- b[grupo=="treated", v]; n <- b[grupo=="never", v]
  t <- t[is.finite(t)]; n <- n[is.finite(n)]
  if (!length(t) || !length(n)) return(NULL)
  sp <- sqrt((var(t)+var(n))/2)
  data.table(treated=mean(t), never=mean(n), smd=(mean(t)-mean(n))/sp,
             p_t=tryCatch(t.test(t,n)$p.value, error=function(e) NA_real_),
             n_treated=length(t), n_never=length(n))
}
bal <- rbindlist(lapply(vars, function(v) cbind(variavel=v[2], smd(v[1], as.integer(v[3])))), fill=TRUE)
fwrite(bal, file.path(DIR_OUT_DATA, "balanco_tratado_naotratado.csv"))

cat("\n==== (A) MDE (80% poder, 5%): SA vs CS ====\n")
print(res[, .(desfecho, att_cs=round(att_cs,4), MDE_CS=round(mde80_cs,4),
              att_sa=round(att_sa,4), MDE_SA=round(mde80_sa,4), detecta_cs)])
cat("\n==== (B) BALANCO tratados x nunca-tratados (linha de base) ====\n")
print(bal[, .(variavel, treated=round(treated,2), never=round(never,2),
              SMD=round(smd,3), p_t=round(p_t,3))])
