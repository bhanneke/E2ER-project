# 10_robustez_completa.R -------------------------------------------------
# Bateria de robustez do braco de assistencia social, espelhando o artigo-pai
# (R/12_did_multivacina.R, R/13_robustez.R, R/18_robustez_pareceres.R).
# Workhorse: estimador de interacao de Sun & Abraham (2021) via fixest, ATT
# agregado, erros agrupados por municipio. Desfecho-ancora: TAC; demais
# desfechos e o CONTRASTE federal (valor do PBF) como controle-negativo.
#
# Conteudo:
#   A. Especificacoes  : baseline, +controles, EF UF x ano
#   B. Pre-tendencias  : Wald conjunto dos leads
#   C. Heterogeneidade : porte populacional (tercis) e regiao
#   D. Placebo temporal: tratamento fantasma -3 anos (so pre-periodo)
#   E. Subamostras     : exclui capitais; exclui munic. < 5.000 hab.
#   F. Transformacoes  : nivel vs. log; winsorizacao 1%/5% (desfechos de contagem)
#   G. Coortes         : ATT(g) por coorte (Callaway-SantAnna)
#   H. Multidesfecho+FDR: q-valores (Benjamini-Hochberg) + contraste federal
#
# Janela por desfecho: TAC e CRAS comecam depois de 2012 (TAC 2015+, Censo
# SUAS 2012+); usamos a janela observada de cada desfecho. CadUnico/PBF: 2012-2019.
#
# Saidas: output/data/robustez_*.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))
instalar_se_preciso("did")

painel <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
painel[, log_fam_cu    := log1p(familias_cadastradas_cu)]
painel[, log_fam_pbf   := log1p(familias_beneficiarias_pbf)]
painel[, log_valor_pbf := log1p(valor_pago_pbf_ano)]
painel[, log_n_cras    := log1p(n_cras)]
painel[, log_trab_cras := log1p(n_trab_cras)]

CONTROLES <- c("log_pib_pc", "log_pop", "taxa_alfabetizacao")

# Desfechos (rotulo -> coluna). TAC e a ancora; valor_pbf e o contraste federal.
DESF <- c(
  "TAC (atualizacao cadastral)"     = "tx_atual_cad",
  "CadUnico: familias (log)"        = "log_fam_cu",
  "CRAS: trabalhadores (log)"       = "log_trab_cras",
  "CRAS: unidades (log)"            = "log_n_cras",
  "PBF: familias (log)"             = "log_fam_pbf",
  "PBF: valor pago (log)"           = "log_valor_pbf")

# Janela observada de cada desfecho (evita derrubar municipios por NA fora
# dela), SEMPRE limitada a JANELA PRIMARIA (<=2019): alem de 2019 as coortes
# 2020+ estao codificadas g=0 (contaminariam o controle nos proprios pos-
# tratamentos) e entram pandemia/Auxilio Emergencial/Auxilio Brasil.
JAN_MAX <- 2019L
janela_obs <- function(col) {
  a <- painel[ano <= JAN_MAX,
              .(cob = mean(!is.na(get(col)))), by = ano][cob > 0.5, sort(ano)]
  if (!length(a)) return(c(2012L, JAN_MAX)); range(a)
}

# ATT agregado de Sun-Abraham (espelha att_sa do pai) ---------------------
att_sa <- function(df, fe = "id + ano", controles = NULL, pretrend = FALSE) {
  df <- copy(df)[!is.na(y)]
  if (!uniqueN(df[g > 0]$id)) return(data.table(att=NA,ep=NA,p=NA,p_pre=NA,n_trat=0))
  df[, g_sa := ifelse(g == 0, 10000L, g)]
  rhs <- "sunab(g_sa, ano)"
  if (!is.null(controles)) rhs <- paste(rhs, "+", paste(controles, collapse=" + "))
  m <- tryCatch(feols(as.formula(sprintf("y ~ %s | %s", rhs, fe)),
                      data = df, cluster = ~id), error = function(e) NULL)
  if (is.null(m)) return(data.table(att=NA,ep=NA,p=NA,p_pre=NA,n_trat=NA))
  ct <- tryCatch(summary(m, agg="att")$coeftable, error=function(e) NULL)
  att <- if (!is.null(ct)) ct[1,1] else NA_real_
  ep  <- if (!is.null(ct)) ct[1,2] else NA_real_
  p   <- if (!is.null(ct)) ct[1,4] else NA_real_
  p_pre <- NA_real_
  if (pretrend) {
    nm <- grep("ano::-?[0-9]", names(coef(m)), value=TRUE)
    pre <- nm[as.integer(sub(".*::(-?[0-9]+).*","\\1",nm)) < -1]
    if (length(pre) >= 2) p_pre <- tryCatch(fixest::wald(m, pre)$p, error=function(e) NA_real_)
  }
  data.table(att=att, ep=ep, p=p, p_pre=p_pre, n_trat=uniqueN(df[g>0]$id))
}

base_desf <- function(col) {
  w <- janela_obs(col)
  d <- painel[ano >= w[1] & ano <= w[2],
              .(id=cod_ibge6, ano, g, uf, regiao, populacao, y=get(col),
                log_pib_pc, log_pop, taxa_alfabetizacao)]
  # populacao constante por municipio (o painel-pai so cobre 2012-2019; usamos
  # a media observada p/ porte e subamostra na janela estendida da TAC/CRAS).
  pm <- painel[, .(pop_c = mean(populacao, na.rm=TRUE)), by=.(id=cod_ibge6)]
  d <- merge(d, pm, by="id", all.x=TRUE)
  d[, populacao := pop_c][, pop_c := NULL]
  d
}

## ===== A. Especificacoes + B. Pre-tendencias ===========================
espec <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])
  rbindlist(list(
    cbind(desfecho=v, spec="1. Baseline (EF munic + ano)", att_sa(base, pretrend=TRUE)),
    cbind(desfecho=v, spec="2. + controles X_it",
          att_sa(base[complete.cases(base[,..CONTROLES])], controles=CONTROLES)),
    cbind(desfecho=v, spec="3. EF UF x ano (dentro do estado)", att_sa(base, fe="id + ano^uf"))
  ), fill=TRUE)
}), fill=TRUE)
fwrite(espec, file.path(DIR_OUT_DATA, "robustez_especificacoes.csv"))

## ===== C. Heterogeneidade (porte e regiao) =============================
het <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])
  pm <- base[, .(pop=mean(populacao,na.rm=TRUE)), by=id]
  pm[, porte := cut(pop, quantile(pop, c(0,1/3,2/3,1), na.rm=TRUE),
                    labels=c("Pequeno","Medio","Grande"), include.lowest=TRUE)]
  base <- merge(base, pm[,.(id,porte)], by="id")
  por_porte <- rbindlist(lapply(levels(base$porte), function(p)
    cbind(desfecho=v, dim="Porte", grupo=p, att_sa(base[porte==p]))), fill=TRUE)
  por_regiao <- rbindlist(lapply(sort(unique(base$regiao)), function(r)
    cbind(desfecho=v, dim="Regiao", grupo=as.character(r), att_sa(base[regiao==r]))), fill=TRUE)
  rbindlist(list(por_porte, por_regiao), fill=TRUE)
}), fill=TRUE)
fwrite(het, file.path(DIR_OUT_DATA, "robustez_heterogeneidade.csv"))

## ===== D. Placebo temporal =============================================
placebo <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])
  pb <- base[g==0 | ano < g]
  pb[, g := ifelse(g==0, 0L, g - 3L)]
  cbind(desfecho=v, att_sa(pb))
}), fill=TRUE)
placebo[, spec := "Placebo (tratamento -3 anos, so pre-periodo)"]
fwrite(placebo, file.path(DIR_OUT_DATA, "robustez_placebo.csv"))

## ===== E. Subamostras ==================================================
cap <- carregar_codigos()[capital_uf==1, id_municipio_6]
subam <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])
  rbindlist(list(
    cbind(desfecho=v, subamostra="Exclui capitais", att_sa(base[!id %in% cap])),
    cbind(desfecho=v, subamostra="Exclui < 5.000 hab", att_sa(base[populacao>=5000]))
  ), fill=TRUE)
}), fill=TRUE)
fwrite(subam, file.path(DIR_OUT_DATA, "robustez_subamostras.csv"))

## ===== F. Transformacoes (winsorizacao p/ desfechos de contagem) =======
winsor <- function(x, p) { q <- quantile(x, c(p,1-p), na.rm=TRUE); pmin(pmax(x,q[1]),q[2]) }
transf <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])
  b1 <- copy(base)[, y := winsor(y, .01)]
  b5 <- copy(base)[, y := winsor(y, .05)]
  rbindlist(list(
    cbind(desfecho=v, transf="Winsor 1%", att_sa(b1)),
    cbind(desfecho=v, transf="Winsor 5%", att_sa(b5))
  ), fill=TRUE)
}), fill=TRUE)
fwrite(transf, file.path(DIR_OUT_DATA, "robustez_transformacoes.csv"))

## ===== G. ATT por coorte (Callaway-SantAnna) ===========================
coorte <- rbindlist(lapply(names(DESF), function(v) {
  base <- base_desf(DESF[v])[!is.na(y)]
  comp <- base[, .(ok=all(!is.na(y))), by=id][ok==TRUE,id]; base <- base[id %in% comp]
  if (!uniqueN(base[g>0]$id)) return(NULL)
  cs <- tryCatch(did::att_gt(yname="y",tname="ano",idname="id",gname="g",data=base,
            control_group="notyettreated", base_period="universal",
            bstrap=TRUE,cband=TRUE), error=function(e) NULL)
  if (is.null(cs)) return(NULL)
  ag <- tryCatch(did::aggte(cs, type="group", na.rm=TRUE), error=function(e) NULL)
  if (is.null(ag)) return(NULL)
  data.table(desfecho=v, coorte=ag$egt, att=ag$att.egt, ep=ag$se.egt)
}), fill=TRUE)
fwrite(coorte, file.path(DIR_OUT_DATA, "robustez_coorte.csv"))

## ===== H. Multidesfecho + FDR (Benjamini-Hochberg) + contraste =========
multi <- espec[spec=="1. Baseline (EF munic + ano)",
               .(desfecho, att, ep, p)]
multi[, q_fdr := p.adjust(p, method="BH")]
multi[, tipo := fifelse(grepl("PBF", desfecho), "Federal/regrado (contraste)",
               fifelse(grepl("TAC|trabalhadores", desfecho),
                       "Discricionario (mecanismo)", "Cobertura/estoque"))]
fwrite(multi, file.path(DIR_OUT_DATA, "robustez_multidesfecho_fdr.csv"))

cat("\n==== A. ESPECIFICACOES (ATT Sun-Abraham) ====\n")
print(espec[, .(desfecho, spec, att=round(att,4), ep=round(ep,4), p=round(p,3), p_pre=round(p_pre,3))])
cat("\n==== D. PLACEBO TEMPORAL ====\n")
print(placebo[, .(desfecho, att=round(att,4), ep=round(ep,4), p=round(p,3))])
cat("\n==== H. MULTIDESFECHO + FDR ====\n")
print(multi[, .(desfecho, tipo, att=round(att,4), p=round(p,3), q_fdr=round(q_fdr,3))])
