# 11_honestdid.R ---------------------------------------------------------
# Sensibilidade a violacoes das tendencias paralelas (Rambachan & Roth 2023),
# pacote HonestDiD aplicado ao estimador PRINCIPAL (Callaway-SantAnna) via
# honest_did.AGGTEobj. Espelha R/30_honestdid_cs.R do artigo-pai.
# Para cada desfecho e horizonte e in {0,1,2}: ponto de ruptura Mbar* (menor
# magnitude relativa de violacao cujo IC robusto inclui zero). Maior = mais robusto.
# Saida: output/data/honestdid_cs.csv
# ------------------------------------------------------------------------

source(here::here("assistencia_social", "R", "00_setup.R"))
instalar_se_preciso(c("did", "HonestDiD"))
suppressPackageStartupMessages({ library(did); library(HonestDiD) })

painel <- fread(file.path(DIR_OUT_DATA, "painel_assistencia_completo.csv"))
painel[, log_trab_cras := log1p(n_trab_cras)]
painel[, log_fam_cu    := log1p(familias_cadastradas_cu)]
painel[, log_valor_pbf := log1p(valor_pago_pbf_ano)]

ALVO <- list(
  c("tx_atual_cad",  "TAC (ancora)"),
  c("log_trab_cras", "CRAS: trabalhadores (mecanismo)"),
  c("log_fam_cu",    "CadUnico: familias"),
  c("log_valor_pbf", "PBF: valor (contraste federal)"))

# JANELA PRIMARIA (<=2019): fora dela as coortes 2020+ estao codificadas g=0
# (contaminacao do controle) e entram pandemia/AE/AB.
JAN_MAX <- 2019L

# Grade FINA (passo 0,1): (i) se o IC original (Mbar=0) ja inclui zero, o
# breakdown e 0 (nenhuma violacao e necessaria); (ii) caso contrario, o
# breakdown reportado e o menor Mbar testado cujo IC robusto inclui zero
# (o verdadeiro esta em (Mbar*-0,1; Mbar*]).
GRID <- seq(0.1, 1.5, by = 0.1)
linhas <- list()
for (a in ALVO) {
  yc <- a[1]; rot <- a[2]
  df <- painel[ano <= JAN_MAX & is.finite(get(yc)),
               .(id = cod_ibge6, ano, g, y = get(yc))]
  cs <- tryCatch(att_gt(yname="y", tname="ano", idname="id", gname="g",
          data=df, control_group="notyettreated", base_period="universal",
          bstrap=TRUE, cband=TRUE), error=function(e) NULL)
  if (is.null(cs)) { cat("falhou CS:", rot, "\n"); next }
  es <- tryCatch(aggte(cs, type="dynamic", min_e=-3, max_e=2, na.rm=TRUE),
                 error=function(e) NULL)
  if (is.null(es)) next
  for (e in c(0,1,2)) {
    hd0 <- tryCatch(HonestDiD:::honest_did.AGGTEobj(es, e=e,
            type="relative_magnitude", Mbarvec=c(0.5)),
            error=function(err) NULL)
    if (is.null(hd0)) next
    oc <- as.data.table(hd0$orig_ci)
    ic_orig <- paste0("[",round(oc$lb[1],3),", ",round(oc$ub[1],3),"]")
    if (oc$lb[1] <= 0 && oc$ub[1] >= 0) {
      bd <- "0"   # nao-significante ja sob tendencias paralelas exatas
    } else {
      hd <- tryCatch(HonestDiD:::honest_did.AGGTEobj(es, e=e,
              type="relative_magnitude", Mbarvec=GRID),
              error=function(err) NULL)
      if (is.null(hd)) next
      rc <- as.data.table(hd$robust_ci)
      cruza <- rc[lb <= 0 & ub >= 0]
      bd <- if (nrow(cruza)) sprintf("%.1f", min(cruza$Mbar))
            else paste0(">", max(GRID))
    }
    linhas[[paste(rot,e)]] <- data.table(desfecho=rot, horizonte_e=e,
      ic_orig = ic_orig, breakdown_Mbar = bd)
    cat("  ", rot, "e =", e, "| M* =", bd, "\n")
  }
  cat("ok:", rot, "\n")
}
out <- rbindlist(linhas, fill=TRUE)
fwrite(out, file.path(DIR_OUT_DATA, "honestdid_cs.csv"))
cat("\n==== HonestDiD (Rambachan-Roth) sobre Callaway-SantAnna ====\n")
print(out)
