# Mapa de reprodução: do script ao número do artigo

Para o editor de dados e para quem quiser rastrear um valor específico. Cada linha liga o
script que produz um arquivo em `assistencia_social/output/data/` ao lugar do manuscrito
onde esse arquivo é lido. O manuscrito (`assistencia_social/paper_en.qmd`) nunca traz
resultado digitado à mão nas tabelas principais: os valores entram por código inline que lê
esses CSVs.

## Ordem de execução

Os scripts são numerados na ordem em que devem rodar. `00_setup.R` fixa a semente e os
caminhos; os coletores (`01`–`06`) montam o painel; os demais estimam.

## Coleta e construção do painel

| Script | Produz | Fonte externa |
|---|---|---|
| `00b_suplementares_tse_FONTE.R` | `tratamento_suplementares.csv` | TSE, repositório de dados eleitorais |
| `01_tratamento.R` | cópia do tratamento para o braço | — |
| `02_cadunico_pbf_bq.R` | `cadunico_pbf_municipio_ano.csv` | Base dos Dados (BigQuery) |
| `03_igd_tac_mds.R` | `tac_cadunico_municipio_ano.csv` | VIS DATA 3 (MDS/SAGI) |
| `04_censo_suas_cras.R` | `censo_suas_municipio_ano.csv` | Censo SUAS |
| `05_painel.R` | `painel_assistencia_completo.csv` | — |
| `06_painel_completo.R` | `rais_assistencia_municipio_ano.csv` | RAIS via Base dos Dados |

## Estimação: do CSV ao lugar no manuscrito

| Script | CSV | Onde aparece |
|---|---|---|
| `07_did.R` | `resultados_did.csv` | Tabela principal; ATT da TAC na Introdução, nos Resultados e no scorecard |
| `08_robustez.R` | `robustez_especificacoes.csv`, `robustez_placebo.csv`, `robustez_coorte.csv`, `robustez_subamostras.csv`, `robustez_transformacoes.csv` | Apêndices B e C; terceiro crivo do nulo |
| `10_robustez_completa.R` | `robustez_multidesfecho_fdr.csv` | Apêndice A |
| `11_honestdid.R` | `robustez_pretendencias.csv` | Segundo crivo (teste de Wald dos *leads*) |
| `12_hierarquico_spillover.R` | `hierarquico_uf_blups.csv`, `spillover_regiao_saude.csv` | Apêndice G; Limitações |
| `13_poder_balanco.R` | `poder_mde.csv`, `balanco_tratado_naotratado.csv` | MDE de 1,9 p.p. (primeiro crivo); Apêndices F e I |
| `17_censo_suas_vinculo.R`, `18_vinculo_mecanismo.R` | `censo_suas_vinculo_municipio_ano.csv`, `mecanismo_vinculo.csv` | Seção do mecanismo; Apêndice J |
| `15_rais_churn_extract.R`, `16_rais_mecanismo.R` | `mecanismo_rais.csv` | Apêndice J |
| `20_heterogeneidade_incentivo.R` | `heterogeneidade_incentivo.csv`, `heterogeneidade_incentivo_residual.csv`, `heterogeneidade_incentivo_permutacao.csv` | Corte pelo piso do índice. **A intensidade deste script usa a regra de repasse anterior a 2011 e foi substituída pelo `30_`; ver abaixo.** |
| `21_timing_exogeneidade.R` | `timing_duracao_r2.csv`, `timing_icc_tre.csv`, `timing_tac_pretrend.csv` | Apêndice L (exogeneidade do *timing*) |
| `22_tac_fluxo_mensal.R` | `tac_fluxo_mensal_att.csv`, `tac_fluxo_mensal_es.csv` | Apêndice O (quarto crivo, fluxo mensal) |
| `23_psm_tac.R` | `psm_tac_att.csv`, `psm_tac_balanco.csv` | Apêndice P (quinto crivo) |
| `24_piloto_descontinuidade_regular.R`, `25_placebo_piloto_regular.R` | `piloto_descontinuidade_regular.csv`, `placebo_piloto_descontinuidade_regular.csv` | Benchmark de transições regulares, reportado no apêndice com ressalvas |
| `26_selecao_quase_tratados.R` | `airc_crespo_municipios.csv`, `selecao_airc_*.csv` | Apêndice Q.1 (sexto crivo, quase-tratados) |
| `27_tost_tac.R` | `tost_tac.csv` | Teste de equivalência (primeiro crivo); Apêndice Q.2 |
| `28_antecipacao.R` | `antecipacao_tac.csv` | Apêndice Q.3 |
| `29_permutacao_tribunal.R` | `permutacao_tribunal_tac.csv` | Apêndice Q.4 |
| `30_proxy_incentivo_norma.R` | `proxy_incentivo_norma.csv`, `_gradiente`, `_permutacao`, `_residual` | **Seção da assinatura do incentivo e Apêndice N.** Queda de 2,4 p.p. no tercil fraco, gradiente de −0,030, permutação a 2,6%, confundimento de 73% |
| `11_honestdid.R` | `honestdid_cs.csv` | Apêndice E |

## Nota sobre o `20_` e o `30_`

O `20_` mede a intensidade do incentivo por famílias beneficiárias do Bolsa Família per
capita, com a justificativa de que o repasse seria proporcional a esse número. Essa regra
vigorou até a Portaria GM/MDS 319, de 29/11/2011, portanto **antes** da janela deste estudo.
Desde então o repasse é pago por cadastro atualizado de família com renda até meio salário
mínimo. O `30_` reestima o gradiente sobre três medidas, incluindo a correta pela norma, e é
ele que alimenta o manuscrito. O `20_` permanece no pacote porque produz o corte pelo piso
do índice, que continua sendo reportado, e porque a comparação entre as três medidas é
parte da robustez.

## O que NÃO roda a partir do material distribuído

Dois scripts dependem de insumos que não são redistribuídos, e o CSV que eles produzem vai
pronto no pacote:

- **`22_tac_fluxo_mensal.R`** exige o cache de 5.570 respostas JSON do VIS DATA 3, em
  `DADOS/mds_igd/cache_tac/`. O dado é público e o próprio `03_igd_tac_mds.R` documenta como
  reconstruí-lo, mas o volume desaconselha empacotá-lo.
- **`26_selecao_quase_tratados.R`** lê planilhas da tese de doutorado de Ralph Crespo sobre
  ações de investigação judicial eleitoral. O uso foi autorizado pelo autor; a redistribuição
  não. O produto agregado (`airc_crespo_municipios.csv`) segue no pacote.

Todos os demais scripts rodam a partir do que está aqui, com as credenciais de BigQuery para
os coletores que consultam a Base dos Dados.
