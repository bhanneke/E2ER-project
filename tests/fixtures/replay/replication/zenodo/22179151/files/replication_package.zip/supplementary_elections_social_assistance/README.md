# Political Rupture and Selective Damage — Replication Package

Replication code and processed data for the paper **"Political Rupture and Selective
Damage to Local Service Delivery: Evidence from Brazil."**

The study uses the removal of Brazilian mayors from office by the electoral courts —
which triggers an off-cycle *supplementary election* — as a quasi-experimental shock,
and a staggered difference-in-differences design across all 5,570 municipalities, to ask
what such a rupture does inside a single service. The finding is that the damage is
addressed rather than diffuse: the routine the federal government pays for by the unit
holds, the workforce nothing rewards contracts, and the federally ruled benefit does not
respond. The setting is social assistance (CadÚnico/SUAS).

The manuscript is in `assistencia_social/paper_en.pdf` (source: `paper_en.qmd`).

Two documents exist for whoever needs to verify rather than read: `MAPA_REPRODUCAO.md`
maps each script to the file it produces and to the place in the manuscript where that
file is read, and `AMBIENTE.md` records the R version, the platform and the package
versions under which the shipped results were produced.

---

## Repository structure

```
.
├── DADOS/                         # reference banks (municipality crosswalk, IBGE mesh)
│   ├── codigos.csv
│   └── ibge/
├── output/
│   └── data/
│       └── painel_completo.csv    # parent-project panel used by scripts 06 and 21
└── assistencia_social/
    ├── paper_en.qmd / .pdf / .html   # the manuscript (English)
    ├── references.bib
    ├── R/                            # pipeline, scripts 00–30
    └── output/
        ├── data/                     # processed datasets (results + panels)
        └── figures_en/               # manuscript figures (English labels)
```

> The nested `assistencia_social/` layout mirrors the parent project so the scripts
> resolve their paths (`00_setup.R`) without modification.

**Note on language:** the manuscript is in English; the analysis scripts (`R/00–29`)
retain their original Portuguese comments. Comments do not affect the results.

---

## Reproducibility

There are two levels.

**1. Re-render the manuscript (self-contained).**
From `assistencia_social/`, with [Quarto](https://quarto.org/) and a LaTeX install:

```bash
cd assistencia_social
quarto render paper_en.qmd        # -> paper_en.pdf and paper_en.html
```

This reads the processed datasets in `assistencia_social/output/data/` and the figures
in `assistencia_social/output/figures_en/`. No raw data or model re-run is required.

**2. Re-run the analysis.**
From the repository root, the numbered scripts reproduce every table and estimate:

```bash
Rscript assistencia_social/R/07_did.R     # main DiD (all estimators, all outcomes)
Rscript assistencia_social/R/10_robustez_completa.R
Rscript assistencia_social/R/11_honestdid.R
# ... 12–23 for spillover, power, mechanism, timing, heterogeneity, PSM, monthly flow
Rscript assistencia_social/R/26_selecao_quase_tratados.R   # nearly-treated (Crespo AIRCs)
Rscript assistencia_social/R/27_tost_tac.R                 # equivalence test (TOST)
Rscript assistencia_social/R/28_antecipacao.R              # anticipation
Rscript assistencia_social/R/29_permutacao_tribunal.R      # tribunal-block permutation
```

Scripts **07–21**, **23–25** and **27–30** read the processed panel in
`assistencia_social/output/data/` (`painel_assistencia*.csv`) and the reference banks in
`DADOS/`, so they run from the material shipped here. **Two do not**, and their outputs are
shipped ready: `22_tac_fluxo_mensal.R` needs the cache of 5,570 VIS DATA JSON responses
(public, but too bulky to ship; `03_igd_tac_mds.R` documents how to rebuild it), and
`26_selecao_quase_tratados.R` reads spreadsheets from a doctoral thesis whose use was
authorised but whose redistribution was not. The bootstrap seed is fixed in `00_setup.R`. Required R packages
are installed on demand by `00_setup.R` (`data.table`, `fixest`, `did`, `ggplot2`,
optionally `didimputation`, `etwfe`).

Scripts **01–06** rebuild the panel from the raw administrative microdata; that raw data
is **not** versioned here (see below), so this first stage is documentary rather than
executable from this repository alone.

---

## Data and provenance

All shipped data are **municipality-level aggregates** (no personal identifiers).

| Data | Source |
|---|---|
| Registry Update Rate (TAC) and IGD-M components | VIS DATA 3 — MDS/SAGI (monthly municipal series) |
| CRAS units and workforce | SUAS Census — MDS/SAGI |
| CadÚnico, Bolsa Família, RAIS | *Base dos Dados* (BigQuery mirrors of MDS / RAIS) |
| Treatment cohorts (removals / special elections) | TSE Electoral Data Repository |
| Structural controls, municipality mesh | IBGE (2022 Census; `DADOS/ibge/`) |

### What is **not** included

The raw downloaded microdata (~2 GB — e.g. the SUAS Census `.zip`/`.rar` archives) is
**not** versioned here: it is large and some sources were originally credential-gated.
Only the processed datasets, the manuscript figures, and the two reference banks
(`DADOS/codigos.csv`, `DADOS/ibge/`) are kept — the minimum needed to render the paper
and re-run the analysis.

---

## AI transparency

The manuscript reports its use of AI assistance for data extraction, estimator
debugging, and writing/translation; see the "Transparency note on the use of artificial
intelligence" section of the paper. All results were verified by the authors.

---

## Citation

If you use this material, please cite the accompanying paper (`assistencia_social/paper_en.pdf`).
